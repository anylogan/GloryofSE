#pragma once
#ifndef __STORE_SCENE_H__
#define __STORE_SCENE_H__


#include "cocos2d.h"

class StoreScene :public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();//������Ϊ����Ľ�ͼ
	virtual bool init();
	void storeReturnCallback(Ref* pSender);
	CREATE_FUNC(StoreScene);
};


#endif