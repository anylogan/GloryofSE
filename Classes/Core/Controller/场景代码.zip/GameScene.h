#pragma once
#include "cocos2d.h"
#include"Core/Controller/GameController.h"
#include"Scene/SelectHeroScene.h"
#include"Scene/StoreScene.h"

class GameScene : public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();
	virtual bool init();
	void storeItemCallback(Ref *pSender);// �����̳�
	void equipmentItemCallback(Ref *pSender);//����װ���鿴
	CREATE_FUNC(GameScene);
};