#include"StoreScene.h"
USING_NS_CC;

Scene* StoreScene::createScene()
{
	return StoreScene::create();
}

bool StoreScene::init()
{
	if (!Scene::init())
	{
		return false;
	}
	auto visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	//�̵����
	Sprite *storebg = Sprite::create("storeground.png");
	storebg->setPosition(Vec2(origin.x + visibleSize.width / 2, origin.y + visibleSize.height / 2));
	addChild(storebg);

	//���ذ�ť
	MenuItemImage *storeReturn = MenuItemImage::create("storereturn.png", "backbutton.png", CC_CALLBACK_1(StoreScene::storeReturnCallback, this));
	//auto storeReturn = Sprite::create("storereturn.png");
	storeReturn->setPosition(Vec2(640,55));
	
	Menu *mu = Menu::create(storeReturn,NULL);
	mu->setPosition(Vec2::ZERO);
	storebg->addChild(mu);
	return true;
}

void StoreScene::storeReturnCallback(Ref* pSender)
{
	log("Menu clicked");
	Director::getInstance()->popScene();
}